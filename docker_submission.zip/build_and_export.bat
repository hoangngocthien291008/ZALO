@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ==============================================================================
REM Script đóng gói Docker Image chuẩn quy chế Zalo AI Challenge 2026 trên Windows
REM ==============================================================================

set RAW_NAME=%*
if "%RAW_NAME%"=="" set RAW_NAME=myteam

REM Tự động chuẩn hóa tên đội: chữ thường, không dấu, không dấu cách theo đúng chuẩn Docker & BTC
for /f "tokens=*" %%i in ('python -c "import sys, unicodedata, re; raw = ' '.join(sys.argv[1:]); nfkd = unicodedata.normalize('NFKD', raw); ascii_str = ''.join([c for c in nfkd if not unicodedata.combining(c)]); print(re.sub(r'[^a-z0-9]+', '_', ascii_str.lower()).strip('_') or 'myteam')" %RAW_NAME%') do set TEAM_NAME=%%i

set IMAGE_NAME=zaic2026_datamate_%TEAM_NAME%:final
set ARCHIVE_NAME=zaic2026_datamate_%TEAM_NAME%.tar
set GZ_NAME=zaic2026_datamate_%TEAM_NAME%.tar.gz

echo ==================================================================
echo BƯỚC 1: Build Docker Image cho nền tảng linux/amd64
echo   Tên Image chuẩn hóa: %IMAGE_NAME%
echo ==================================================================
docker build --platform linux/amd64 -t %IMAGE_NAME% .

if errorlevel 1 (
    echo [LỖI] Build Docker thất bại! Hãy đảm bảo Docker Desktop đang bật.
    exit /b 1
)

echo.
echo ==================================================================
echo BƯỚC 2: Kiểm tra kiến trúc và kích thước Image
echo ==================================================================
docker image inspect -f "{{.Os}}/{{.Architecture}} | Kích thước: {{.Size}} bytes" %IMAGE_NAME%

echo.
echo ==================================================================
echo BƯỚC 3: Xuất Docker Image ra file .tar và nén thành .tar.gz
echo ==================================================================
docker save %IMAGE_NAME% -o %ARCHIVE_NAME%

echo Đang nén file %ARCHIVE_NAME% thành %GZ_NAME%...
tar -czvf %GZ_NAME% %ARCHIVE_NAME%
del %ARCHIVE_NAME%

echo.
echo ==================================================================
echo BƯỚC 4: Tạo mã MD5 Checksum
echo ==================================================================
powershell -Command "Get-FileHash -Path '%GZ_NAME%' -Algorithm MD5 | ForEach-Object { $_.Hash.ToLower() + '  %GZ_NAME%' } | Set-Content '%GZ_NAME%.md5'"
type %GZ_NAME%.md5

echo.
echo ==================================================================
echo HOÀN TẤT ĐÓNG GÓI!
echo Upload file %GZ_NAME% lên Google Drive và lấy mã MD5 để nộp cho BTC!
echo ==================================================================
